## 1.5.0
* Retry failed requests by default.
* Throw clearer errors when curl is installed but disabled.

## 1.4.0
* Support for HTTP proxies.
