<?php
class Tiny_CompressImages_Exception extends Exception
{
}
