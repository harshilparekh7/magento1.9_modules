/**
 * Copyright © 2016 ShopGo. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            'Magento_Checkout/js/model/shipping-rate-processor/new-address': 'ShopGo_CheckoutCity/js/model/shipping-rate-processor/new-address'
        }
    }
};
