# Aoe Quote Cleaner

Allows you to clean up the quote tables in a scheduler task.
Check the system configuration for the settings on how old quotes (from anonymous and from logged in users) can be before
they will be deleted.