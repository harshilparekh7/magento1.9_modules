<?php
$UTF8_TO_ASCII[0x63] = array(

);
