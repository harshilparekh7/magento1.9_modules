<?php
$UTF8_TO_ASCII[0x6e] = array(

);
