var config = {
    "map": {
        "*": {
            "Magento_Checkout/js/model/shipping-save-processor/default" : "Oye_Deliverydate/js/shipping-save-processor-default-override",
            "Oye_Deliverydate/js/delivery-date" : "Oye_Deliverydate/js/delivery-date"
        }
    }
};