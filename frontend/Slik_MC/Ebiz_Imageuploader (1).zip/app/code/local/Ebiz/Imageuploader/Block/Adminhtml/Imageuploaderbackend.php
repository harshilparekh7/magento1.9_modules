<?php  

class Ebiz_Imageuploader_Block_Adminhtml_Imageuploaderbackend extends Mage_Adminhtml_Block_Template {

}