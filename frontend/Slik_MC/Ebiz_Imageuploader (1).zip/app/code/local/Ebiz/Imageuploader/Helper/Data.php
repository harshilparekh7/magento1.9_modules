<?php
class Ebiz_Imageuploader_Helper_Data extends Mage_Core_Helper_Abstract
{
}
	 