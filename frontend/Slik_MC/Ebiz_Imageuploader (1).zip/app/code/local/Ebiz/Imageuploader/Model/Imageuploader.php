<?php

class Ebiz_Imageuploader_Model_Imageuploader extends Mage_Core_Model_Abstract
{
    protected function _construct(){

       $this->_init("imageuploader/imageuploader");

    }

}
	 