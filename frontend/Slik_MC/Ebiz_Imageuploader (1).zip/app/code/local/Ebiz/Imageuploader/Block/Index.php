<?php   
class Ebiz_Imageuploader_Block_Index extends Mage_Core_Block_Template{   





}