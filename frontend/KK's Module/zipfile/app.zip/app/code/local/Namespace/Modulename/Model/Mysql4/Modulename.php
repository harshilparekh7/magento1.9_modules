<?php

class <Namespace>_<Module>_Model_Mysql4_<Module> extends Mage_Core_Model_Mysql4_Abstract
{
    public function _construct()
    {    
        $this->_init('<module>/<module>', '<module>_id');
    }
} 