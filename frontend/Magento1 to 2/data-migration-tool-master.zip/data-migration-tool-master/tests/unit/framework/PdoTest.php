<?php
/**
 * Copyright © 2013-2017 Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Migration\TestFramework;

class PdoTest extends \PDO
{
    /**
     *
     */
    public function __construct()
    {
    }
}
