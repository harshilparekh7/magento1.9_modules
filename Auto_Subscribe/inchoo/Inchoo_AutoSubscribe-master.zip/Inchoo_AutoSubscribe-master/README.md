Inchoo_AutoSubscribe
====================

Inchoo_AutoSubscribe is a Magento module allowing you to hide newsletter opt-in checkbox from create account page and automatically subscribe your customers to newsletter when they register or place an order. Customers are left with the option to permanently unsubscribe using their account dashboard at any time.

For more details you can visit my [article at inchoo.net](http://inchoo.net/ecommerce/magento/newsletter-auto-subscribe-create-account-place-order-magento/).
