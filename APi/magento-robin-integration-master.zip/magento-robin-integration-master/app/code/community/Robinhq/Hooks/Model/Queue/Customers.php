<?php

class Robinhq_Hooks_Model_Queue_Customers extends Robinhq_Hooks_Model_Queue_Abstract
{

    /**
     * @return string
     */
    public function getAction()
    {
        return 'customers';
    }

}