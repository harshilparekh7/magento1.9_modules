<?php


class Robinhq_Hooks_Model_Exception_UnknownStatusCodeException extends Robinhq_Hooks_Model_Exception_Abstract
{
    protected $message = "The returned status code is unknown";
}