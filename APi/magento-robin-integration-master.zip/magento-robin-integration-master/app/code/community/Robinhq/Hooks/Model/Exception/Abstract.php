<?php

class Robinhq_Hooks_Model_Exception_Abstract extends Exception {}
