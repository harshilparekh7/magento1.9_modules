<?php  

class Robinhq_Hooks_Block_Adminhtml_Hooksbackend extends Mage_Adminhtml_Block_Template {
}