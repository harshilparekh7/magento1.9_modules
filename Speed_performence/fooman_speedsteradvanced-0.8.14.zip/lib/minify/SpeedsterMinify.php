<?php

class SpeedsterMinify extends Minify
{

}