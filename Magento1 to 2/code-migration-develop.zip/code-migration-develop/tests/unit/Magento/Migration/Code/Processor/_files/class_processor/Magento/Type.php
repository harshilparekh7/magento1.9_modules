<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento;

class Type
{
    public function __construct(
        $input1,
        $input2 = null,
        array $input3 = [],
        $input4 = true,
        $input5 = false
    ) {
        //echo 'hello';
    }
}