Ultimate Module Creator 1.9.6.0
======
## Notice

<strong>Because of lack of time, motivation and because Magento2 is already a mature platform, I'm deciding to pull the plug on this module creator.  
There will be no updates, no new features.  

Feel free to fork it, make it better and redestribute it. </strong>


<strike>New</strike> Ultimate Module Creator for Magento 1.7 +
-------------

This is the new version of <a href="https://github.com/tzyganu/moduleCreator">Ultimate Module Creator</a>.


This should be the version 2.0 of the Magento extension but I'm keeping this version for the Module Creator for Magento 2.0.  

Backwards compatibility has been broken.

If someone wants to help with the testing please submit any bugs, improvements or feature requests <a href="https://github.com/tzyganu/UMC1.9/issues">here</a>

Also any good code is welcomed.

**Note**
For the rest of the document UMC = Ultimate Module Creator

Documentation can be found on the [wiki pages](https://github.com/tzyganu/UMC1.9/wiki/).  
The documentation includes a list of [features](https://github.com/tzyganu/UMC1.9/wiki/features) and [release notes](https://github.com/tzyganu/UMC1.9/wiki/release-notes)  




